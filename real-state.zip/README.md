<<<<<<< HEAD
# real-estate-website
currently im building this website for my client...

=======
# Getting Started 
 so i'am started this project its for a client that he need it for making new website
 so here i do the project untill its done.

 i want make it using React.js , Tailwind in React 

