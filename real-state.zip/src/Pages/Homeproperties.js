import React from 'react'

function Homeproperties() {
  return (
    <div className='bg-blue-400'></div>
  )
}

export default Homeproperties