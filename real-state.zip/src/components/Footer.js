import React from 'react'

export default function Footer() {
  return (
    <div className='bg-black py-8 '>
        <h1 className='text-center text-white'> sajad ساخته شده توسط  </h1>
    </div>
  )
}
